# Online Food Ordering Website

A responsive food ordering website built with HTML, CSS and JavaScript.
Open index.html in a browser to run it.

Features: dynamic menu, category filter, search, cart with quantities and totals, order summary, form validation and Local Storage.
