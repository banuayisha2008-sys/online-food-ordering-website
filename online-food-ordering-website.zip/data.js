// data.js - menu items used by the Online Food Ordering Website
const menuItems = [
  { id: 1,  name: "Margherita Pizza",   category: "Pizza",    price: 249, icon: "🍕", bg: "#fde8d8", desc: "Thin crust topped with tomato sauce, mozzarella and fresh basil." },
  { id: 2,  name: "Farmhouse Pizza",    category: "Pizza",    price: 329, icon: "🍕", bg: "#fdebc8", desc: "Loaded with capsicum, onion, mushroom and sweet corn." },
  { id: 3,  name: "Veg Burger",         category: "Burgers",  price: 119, icon: "🍔", bg: "#fff1c9", desc: "Crispy vegetable patty with lettuce, tomato and house sauce." },
  { id: 4,  name: "Chicken Burger",     category: "Burgers",  price: 159, icon: "🍔", bg: "#fbe0cf", desc: "Juicy fried chicken fillet with cheese slice and mayo." },
  { id: 5,  name: "Chicken Biryani",    category: "Rice",     price: 220, icon: "🍛", bg: "#fdebc8", desc: "Seeraga samba rice cooked with tender chicken and spices." },
  { id: 6,  name: "Veg Fried Rice",     category: "Rice",     price: 130, icon: "🍚", bg: "#e9f4dc", desc: "Wok-tossed rice with fresh vegetables and soy sauce." },
  { id: 7,  name: "Masala Dosa",        category: "Tiffin",   price: 80,  icon: "🥞", bg: "#fff3cf", desc: "Golden crispy dosa filled with spiced potato masala." },
  { id: 8,  name: "Idli (3 pieces)",    category: "Tiffin",   price: 50,  icon: "⚪", bg: "#eef2f7", desc: "Soft steamed idlis served with sambar and two chutneys." },
  { id: 9,  name: "Paneer Butter Masala", category: "Curries", price: 190, icon: "🍲", bg: "#fbdcd0", desc: "Cottage cheese cubes in a rich, creamy tomato gravy." },
  { id: 10, name: "French Fries",       category: "Snacks",   price: 90,  icon: "🍟", bg: "#fff1c9", desc: "Golden salted fries served with tomato ketchup." },
  { id: 11, name: "Veg Sandwich",       category: "Snacks",   price: 70,  icon: "🥪", bg: "#e9f4dc", desc: "Grilled sandwich stuffed with veggies and mint chutney." },
  { id: 12, name: "Chocolate Brownie",  category: "Desserts", price: 110, icon: "🍫", bg: "#ecdcd2", desc: "Warm fudgy brownie with a drizzle of chocolate sauce." },
  { id: 13, name: "Ice Cream Sundae",   category: "Desserts", price: 99,  icon: "🍨", bg: "#fde4ee", desc: "Vanilla scoops with nuts, cherry and strawberry syrup." },
  { id: 14, name: "Cold Coffee",        category: "Drinks",   price: 85,  icon: "🥤", bg: "#ede0d4", desc: "Chilled blended coffee topped with whipped cream." },
  { id: 15, name: "Fresh Lime Soda",    category: "Drinks",   price: 45,  icon: "🍋", bg: "#f2f7cf", desc: "Refreshing lime soda, served sweet or salted." }
];
