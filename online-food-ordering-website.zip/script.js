// script.js - logic for the Online Food Ordering Website

const STORAGE_KEY = "tastybites_cart";
let cart = [];                 // [{ id, qty }]
let activeCategory = "All";
let searchText = "";

// ---------- helpers ----------
const $ = (id) => document.getElementById(id);
const rupees = (n) => "₹" + n.toLocaleString("en-IN");
const findItem = (id) => menuItems.find((m) => m.id === id);

// ---------- local storage ----------
function saveCart() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(cart)); } catch (e) { /* storage blocked */ }
}
function loadCart() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (Array.isArray(saved)) {
      // keep only items that still exist in the menu
      cart = saved.filter((c) => findItem(c.id) && c.qty > 0);
    }
  } catch (e) { cart = []; }
}

// ---------- menu ----------
function buildFilters() {
  const cats = ["All", ...new Set(menuItems.map((m) => m.category))];
  $("categoryFilters").innerHTML = cats
    .map((c) => `<button class="filter-btn ${c === activeCategory ? "active" : ""}" data-cat="${c}">${c}</button>`)
    .join("");
}

function renderMenu() {
  const list = menuItems.filter((m) => {
    const catOk = activeCategory === "All" || m.category === activeCategory;
    const nameOk = m.name.toLowerCase().includes(searchText.toLowerCase().trim());
    return catOk && nameOk;
  });

  $("resultNote").textContent = `Showing ${list.length} of ${menuItems.length} dishes`;

  if (list.length === 0) {
    $("foodGrid").innerHTML = `<div class="empty-msg">No dishes found. Try a different name or category.</div>`;
    return;
  }

  $("foodGrid").innerHTML = list.map((m) => `
    <div class="food-card">
      <div class="food-img" style="--tile:${m.bg}"><span class="food-icon">${m.icon}</span></div>
      <div class="food-body">
        <span class="tag">${m.category}</span>
        <h3>${m.name}</h3>
        <p>${m.desc}</p>
        <div class="food-foot">
          <span class="price">${rupees(m.price)}</span>
          <button class="add-btn" data-add="${m.id}">Add</button>
        </div>
      </div>
    </div>`).join("");
}

// ---------- cart ----------
function addToCart(id) {
  const line = cart.find((c) => c.id === id);
  if (line) line.qty++;
  else cart.push({ id, qty: 1 });
  updateCart();
}

function changeQty(id, delta) {
  const line = cart.find((c) => c.id === id);
  if (!line) return;
  line.qty += delta;
  if (line.qty <= 0) cart = cart.filter((c) => c.id !== id);
  updateCart();
}

function removeFromCart(id) {
  cart = cart.filter((c) => c.id !== id);
  updateCart();
}

function getTotal() {
  return cart.reduce((sum, c) => sum + findItem(c.id).price * c.qty, 0);
}

function updateCart() {
  const count = cart.reduce((n, c) => n + c.qty, 0);
  $("cartCount").textContent = count;

  if (cart.length === 0) {
    $("cartItems").innerHTML = `<div class="cart-empty">Your cart is empty.<br>Add something tasty from the menu!</div>`;
    $("cartTotal").innerHTML = "";
    $("checkoutBtn").disabled = true;
    $("clearBtn").style.display = "none";
  } else {
    $("cartItems").innerHTML = cart.map((c) => {
      const item = findItem(c.id);
      return `
        <div class="cart-row">
          <div class="top"><span>${item.name}</span><span>${rupees(item.price * c.qty)}</span></div>
          <div class="bottom">
            <div class="qty">
              <button data-minus="${item.id}">−</button>
              <span>${c.qty}</span>
              <button data-plus="${item.id}">+</button>
              <small>× ${rupees(item.price)}</small>
            </div>
            <button class="remove-btn" data-remove="${item.id}">Remove</button>
          </div>
        </div>`;
    }).join("");
    $("cartTotal").innerHTML = `<span>Total</span><span>${rupees(getTotal())}</span>`;
    $("checkoutBtn").disabled = false;
    $("clearBtn").style.display = "block";
  }
  saveCart();
}

// ---------- checkout ----------
function openCheckout() {
  if (cart.length === 0) return;
  const rows = cart.map((c) => {
    const item = findItem(c.id);
    return `<tr><td>${item.name}</td><td>${c.qty}</td><td class="r">${rupees(item.price)}</td><td class="r">${rupees(item.price * c.qty)}</td></tr>`;
  }).join("");
  $("orderSummary").innerHTML = `
    <table>
      <tr><th>Item</th><th>Qty</th><th class="r">Price</th><th class="r">Subtotal</th></tr>
      ${rows}
      <tr class="grand"><td colspan="3">Order Total</td><td class="r">${rupees(getTotal())}</td></tr>
    </table>`;
  $("checkoutModal").classList.add("open");
}

function showError(inputId, errId, message) {
  $(errId).textContent = message;
  $(inputId).classList.toggle("input-bad", message !== "");
  return message === "";
}

function validateForm() {
  const name = $("custName").value.trim();
  const phone = $("custPhone").value.trim();
  const address = $("custAddress").value.trim();
  const pay = $("payMode").value;

  const nameOk = showError("custName", "nameErr",
    name.length < 3 ? "Please enter your full name (at least 3 characters)." :
    !/^[A-Za-z .]+$/.test(name) ? "Name should contain only letters." : "");

  const phoneOk = showError("custPhone", "phoneErr",
    !/^[6-9]\d{9}$/.test(phone) ? "Enter a valid 10-digit mobile number." : "");

  const addrOk = showError("custAddress", "addrErr",
    address.length < 10 ? "Please enter a complete delivery address." : "");

  const payOk = showError("payMode", "payErr", pay === "" ? "Please choose a payment method." : "");

  return nameOk && phoneOk && addrOk && payOk;
}

function placeOrder(e) {
  e.preventDefault();
  if (cart.length === 0 || !validateForm()) return;

  const orderNo = "TB" + Date.now().toString().slice(-6);
  $("successMsg").innerHTML =
    `Thank you, <b>${$("custName").value.trim()}</b>!<br>` +
    `Order <b>#${orderNo}</b> of <b>${rupees(getTotal())}</b> will reach you in about 35 minutes.`;

  cart = [];
  updateCart();
  $("orderForm").reset();
  ["nameErr", "phoneErr", "addrErr", "payErr"].forEach((id) => ($(id).textContent = ""));
  $("checkoutModal").classList.remove("open");
  $("successModal").classList.add("open");
}

// ---------- events ----------
document.addEventListener("click", (e) => {
  const t = e.target;
  if (t.dataset.cat) { activeCategory = t.dataset.cat; buildFilters(); renderMenu(); }
  if (t.dataset.add) addToCart(Number(t.dataset.add));
  if (t.dataset.plus) changeQty(Number(t.dataset.plus), 1);
  if (t.dataset.minus) changeQty(Number(t.dataset.minus), -1);
  if (t.dataset.remove) removeFromCart(Number(t.dataset.remove));
});

$("searchBox").addEventListener("input", (e) => { searchText = e.target.value; renderMenu(); });
$("checkoutBtn").addEventListener("click", openCheckout);
$("clearBtn").addEventListener("click", () => { cart = []; updateCart(); });
$("cancelBtn").addEventListener("click", () => $("checkoutModal").classList.remove("open"));
$("okBtn").addEventListener("click", () => $("successModal").classList.remove("open"));
$("orderForm").addEventListener("submit", placeOrder);
$("cartToggle").addEventListener("click", () => $("cartPanel").scrollIntoView({ behavior: "smooth" }));

// ---------- start ----------
loadCart();
buildFilters();
renderMenu();
updateCart();
